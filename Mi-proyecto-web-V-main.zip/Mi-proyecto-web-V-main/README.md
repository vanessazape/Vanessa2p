# Vanessa's Brainy Cup
Este es el repositorio wed de la clase de gestiòn con el docente Felipe V sobre mi proyecto de vida  
